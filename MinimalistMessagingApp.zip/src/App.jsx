import React from "react";
import MessagingApp from "./MessagingApp";

export default function App() {
  return <MessagingApp />;
}
